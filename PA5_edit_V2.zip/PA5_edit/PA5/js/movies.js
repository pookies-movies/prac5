window.onload = function(){
    //loadingScreen();
    clearInnerHTML();
    getAllMovies();
    document.getElementById('search-select').addEventListener('change', function() {
        const type = this.value;
        clearInnerHTML();
        getAllSeries(type);
    });

    document.getElementById('filter-selector').addEventListener('change', function() {
        const type = this.value;
        clearInnerHTML();
        getAllFilterMovies(type);
    });
}

function clearInnerHTML(){
    let movieItems = document.querySelectorAll('.slick-multiItemSlider .movie-item');
    movieItems.forEach(movieItem => {
        console.log(movieItem.innerHTML);
    });
    movieItems.forEach(movieItem => {
        movieItem.innerHTML = '';
    });
}

function getAllMovies(){
    //loadingScreen();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListHTML(listingIndex);
                }
                //hideLoadingScreen();
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        fuzzy: true,
        recommend: true,
        return: ['Title', 'MovieID', 'Rating', 'Runtime', 'AgeRating', 'Genre', 'CrewID', 'ReleaseYear', 'Image']
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
}

function populateListHTML(listData){
    let listingsContainer = document.querySelector('.slick-multiItemSlider');
    let listElement = document.createElement('div');
    listElement.classList.add('movie-item');
    listElement.innerHTML = `
        <div class="mv-img">
            <!--link to the movie-->
            <a href="moviesingle.html"><img src="${listData.Image}" alt="" width="285" height="437"></a>
        </div>
        <div class = "title-in" id = "${listData.MovieID}">
            <div class="cate">
                <span class="blue"><a href="#">${listData.Genre}</a></span>
            </div>
            <h6><a href="moviesingle.html">${listData.Title}</a></h6>
            <p><i class="ion-android-star"></i><span>${listData.Rating}</span> /10</p>
        </div>
    `;

    listingsContainer.appendChild(listElement);
}

function populateListSeriesHTML(listData){
    let listingsContainer = document.querySelector('.slick-multiItemSlider');
    let listElement = document.createElement('div');
    listElement.classList.add('movie-item');
    listElement.innerHTML = `
        <div class="mv-img">
            <!--link to the movie-->
            <a href="moviesingle.html"><img src="" alt="" width="285" height="437"></a>
        </div>
        <div class = "title-in" id = "${listData.SeriesID}">
            <div class="cate">
                <span class="blue"><a href="#">${listData.Genre}</a></span>
            </div>
            <h6><a href="moviesingle.html">${listData.Title}</a></h6>
            <p><i class="ion-android-star"></i><span>${listData.Rating}</span> /10</p>
        </div>
    `;

    listingsContainer.appendChild(listElement);
}

/*-----------------------------------------------------------------------------------------------------------------------------------------*/

function getAllSeries(type){
    //loadingScreen();
    clearInnerHTML();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListSeriesHTML(listingIndex);
                }
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: type,
        apikey: api,
        recommend: true,
        return: ['Title', 'MovieID', 'Rating', 'Runtime', 'AgeRating', 'Genre', 'CrewID', 'ReleaseYear', 'Image']
    };

    xmlObject.send(JSON.stringify(reqData));
}

function search(){
    //loadingScreen();
    let data = document.getElementById('search-input').value;
    clearInnerHTML();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateMovieListHTML(listingIndex);
                }
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        search: data,
        fuzzy: true
    };

    xmlObject.send(JSON.stringify(reqData));
}

function populateMovieListHTML(listData){
    let listingsContainer = document.querySelector('.slick-multiItemSlider');
    let listElement = document.createElement('div');
    listElement.classList.add('movie-item');
    listElement.innerHTML = `
        <div class="mv-img">
            <!--link to the movie-->
            <a href="moviesingle.html"><img src="" alt="" width="285" height="437"></a>
        </div>
        <div class = "title-in" id = "${listData.MovieID}">
            <div class="cate">
                <span class="blue"><a href="#">${listData.Genre}</a></span>
            </div>
            <h6><a href="moviesingle.html">${listData.Title}</a></h6>
            <p><i class="ion-android-star"></i><span>${listData.Rating}</span> /10</p>
        </div>
    `;

    listingsContainer.appendChild(listElement);
}