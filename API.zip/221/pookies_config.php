<?php
    $conn = mysqli_connect('wheatley.cs.up.ac.za', 'u23547627', 'JDTGHQ2UCAP3PNOHPRKHI3TI7X3L5ETK', 'u23547627_properties');

    if (!$conn){
        die('Connection error: ' . mysqli_connect_error());
    }

    //mysqli_close($conn);


