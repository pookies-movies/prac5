<?php
    session_start();
    require 'pookies_config.php';

    class API{
        private static $instance;
        private $dataBase;

        private function __construct($db){
            $this->dataBase = $db;
        }

        public static function getInstance($db){
            if (!isset(self::$instance)){
                self::$instance = new API($db);
            }
            
            return self::$instance;
        }

        public function login($data){
            $email = $data['email'];
            $password = $data['password'];

            $result = $this->dataBase->query("SELECT * FROM users WHERE email='$email'");

            if ($result->num_rows === 0) {
                return $this->response("error", "User does not exist", 400);
            }

            $userData = $result->fetch_assoc();
            $dbHashedPassword = $userData['password'];
            
            if (password_verify($password, $dbHashedPassword)){
                $apiKeyResult = $this->dataBase->query("SELECT API_key FROM users WHERE email='$email'");
                $apiKey = $apiKeyResult->fetch_assoc()['API_key'];
                $_SESSION['API_KEY'] = $apiKey;
                return $this->response("success", "Logged In", 200, array("apikey" => $apiKey));
            } 
            
            else{
                return $this->response("error", "Incorrect password", 400);
            }
        }

        public function register($data){
            if (!isset($data['name']) || $data['name'] == "" || !isset($data['surname']) || $data['surname'] == "" || !isset($data['email']) || $data['email'] == "" || !isset($data['password']) || $data['password'] == ""){
                return $this->response("error", "Missing fields", 400);
            }

            if (!preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$/", $data['email'])){
                return $this->response("error", "Invalid email format", 400);
            }

            if (!preg_match("/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/", $data['password'])){
                return $this->response("error", "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one symbol", 400);
            }

            $email = $data['email'];
            $result = $this->dataBase->query("SELECT * FROM users WHERE email='$email'");

            if ($result->num_rows > 0){
                return $this->response("error", "User already exists", 400);
            }

            //$salt = $this->generateSalt();
            $password = $this->hashingFunction($data['password']);

            $apiKey = $this->generateAPI();

            $name = $data['name'];
            $surname = $data['surname'];          
            
            $stmt = $this->dataBase->prepare("INSERT INTO users (name, surname, email, password, API_key) VALUES (?, ?, ?, ?, ?)");
            
            if (!$stmt){
                return $this->response("error", "Failed to prepare SQL statement: " . $this->dataBase->error, 500);
            }

            $stmt->bind_param("sssss", $name, $surname, $email, $password, $apiKey);

            if ($stmt->execute()){
                return $this->response("success", "User registered successfully", 200, array("apikey" => $apiKey));
            } 

            if (!$stmt->execute()) {
                // Handle error, e.g., log it or return an error response
                return $this->response("error", "Failed to execute SQL statement: " . $stmt->error, 500);
            }
            
            else{
                return $this->response("error", "Failed to register user", 500);
            }

        }

        public function hashingFunction($password){
            return password_hash($password, PASSWORD_DEFAULT);
        }

        /*public function generateSalt(){
            return substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 15);
        }*/

        private function generateAPI(){
            return substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 20);
        }

        public function response($status, $message, $code, $data = null){
            header("Content-Type: application/json");
            http_response_code($code);
            $timestamp = (string) time();
            $response = array(
                "status" => $status,
                "message" => $message,
                "timestamp" => $timestamp,
                "data" => $data
            );
            return json_encode($response);
        }

        public function getAllMovies($data){
            if (!isset($data['apikey']) || !isset($data['type']) || !isset($data['return'])){
                return $this->response("error", "Post parameters are missing", 400);
            }
            
            $apiKey = $data['apikey'];
            $result = $this->dataBase->query("SELECT * FROM users WHERE API_key='$apiKey'");

            if ($result->num_rows == 0){
                return $this->response("error", "API does not exist", 401);
            }

            $sql = "SELECT ";

            if (in_array('*', $data['return'])){
                $sql .= "*";
            } 
            
            else{
                $sql .= implode(",", $data['return']);
            }

            $sql .= " FROM listings";

            if (isset($data['search']) && is_array($data['search']) && count($data['search']) > 0){
                $conditions = [];

                foreach ($data['search'] as $column => $value){
                    $value = $this->dataBase->real_escape_string($value);
                    
                    if ($column === 'price_min'){
                        $conditions[] = "price >= '$value'";
                    } 
                    
                    else if ($column === 'price_max'){
                        $conditions[] = "price <= '$value'";
                    }
                    
                    else if (isset($data['fuzzy']) && $data['fuzzy'] === true){
                        $conditions[] = "$column LIKE '%$value%'";
                    }

                    else{
                        $conditions[] = "$column = '$value'";
                    }
                }
                $sql .= " WHERE " . implode(" AND ", $conditions);
            }

            if (isset($data['sort']) && in_array($data['sort'], ['id', 'title', 'location', 'price', 'bedrooms', 'bathrooms', 'parking spaces'])){
                $sql .= " ORDER BY {$data['sort']}";

                if (isset($data['order']) && in_array($data['order'], ['ASC', 'DESC'])) {
                    $sql .= " {$data['order']}";
                }
            }

            if (isset($data['limit']) && is_numeric($data['limit'])){
                $sql .= " LIMIT " . intval($data['limit']);
            }

            $listingResult = $this->dataBase->query($sql);

            if (!$listingResult){
                return $this->response("error", "Failed to fetch listings", 500);
            }

            $listings = [];

            while ($row = $listingResult->fetch_assoc()){
                if (isset($data['return']) && is_array($data['return'])){
                    foreach ($data['return'] as $param){

                        if (array_key_exists($param, $row)){
                            $listing[$param] = is_numeric($row[$param]) ? intval($row[$param]) : $row[$param];
                        }
                    }
                }

                if (in_array('images', $data['return'])) {
                    $listing['images'] = $this->getImages($row['id']);
                }

                $listings[] = $listing;
            }

            return $this->response("success", "Listings retrieved successfully", 200, $listings);
        }

        private function getImages($id){
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, "https://wheatley.cs.up.ac.za/api/getimage?listing_id=$id");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $result = curl_exec($ch);

            if (curl_errno($ch)) {
                curl_close($ch);
                return [];
            }

            curl_close($ch);
    
            $data = json_decode($result, true);
            $images = $data['data'];
            
            return $images;
        }

        public function recommend($data){
            if (!isset($data['apikey']) || !isset($data['product_id']) || !isset($data['action']) || !isset($data['otherUser'])){
                return $this->response("error", "Required parameters are missing", 400);
            }
        
            $apiKey = $data['apikey'];
            $productId = $data['product_id'];
            $action = $data['action'];
        
            $result = $this->dataBase->query("SELECT * FROM users WHERE API_key='$apiKey'");
        
            if ($result->num_rows == 0){
                return $this->response("error", "API key is invalid", 401);
            }

            $listingResult = $this->dataBase->query("SELECT * FROM movies WHERE id='$productId'");
            
            if ($listingResult->num_rows == 0){
                return $this->response("error", "Listing does not exist", 404);
            }
        
            $userRow = $result->fetch_assoc();
            $userId = $userRow['id'];
        
            if ($action === 'add'){
                $checkFavouriteResult = $this->dataBase->query("SELECT * FROM recommendations WHERE user_id='$userId' AND product_id='$productId'");

                if ($checkFavouriteResult->num_rows > 0){
                    return $this->response("error", "Listing is already in favorites", 400);
                }

                $stmt = $this->dataBase->prepare("INSERT INTO favourites (user_id, listing_id) VALUES (?, ?)");

                if (!$stmt){
                    return $this->response("error", "Failed to prepare SQL statement: " . $this->dataBase->error, 500);
                }

                $stmt->bind_param("ii", $userId, $listingId);

                if ($stmt->execute()){
                    return $this->response("success", "Listing added successfully", 200, array("apikey" => $apiKey));
                } 
    
                if (!$stmt->execute()){
                    return $this->response("error", "Failed to execute SQL statement: " . $stmt->error, 500);
                }
        
                return $this->response("success", "Listing added to favorites", 200);
            } 
            
            else if ($action === 'remove'){
                $deleteFavorite = $this->dataBase->query("DELETE FROM favourites WHERE user_id='$userId' AND listing_id='$listingId'");

                if (!$deleteFavorite){
                    return $this->response("error", "Failed to remove listing from favorites", 500);
                }
        
                return $this->getFavourites($data);
            } 
            
            else{
                return $this->response("error", "Invalid action parameter", 400);
            }
        }
        
        public function getFavourites($data){
            if (!isset($data['apikey'])){
                return $this->response("error", "API key is missing", 400);
            }
        
            $apiKey = $data['apikey'];
            $result = $this->dataBase->query("SELECT * FROM users WHERE API_key='$apiKey'");
        
            if ($result->num_rows == 0){
                return $this->response("error", "API key is invalid", 401);
            }
        
            $userData = $result->fetch_assoc();
            $userId = $userData['id'];
            $listingIdsResult = $this->dataBase->query("SELECT listing_id FROM favourites WHERE user_id='$userId'");
        
            if (!$listingIdsResult){
                return $this->response("error", "Failed to retrieve favorite listings", 500);
            }
        
            $favoriteListings = [];
        
            while ($row = $listingIdsResult->fetch_assoc()){
                $listingId = $row['listing_id'];
                $listingResult = $this->dataBase->query("SELECT * FROM listings WHERE id='$listingId'");
                
                if ($listingResult){
                    $listing = $listingResult->fetch_assoc();
                    $listing['images'] = $this->getImages($listingId);
                    $favoriteListings[] = $listing;
                }
            }
            
            return $this->response("success", "Favorite listings retrieved successfully", 200, $favoriteListings);
        }

        public function createAuction($data){
            if (!isset($data['api_key']) || $data['api_key'] == "" || !isset($data['auction_id']) || $data['auction_id'] == "" || !isset($data['name']) || $data['name'] == "" || !isset($data['Sdate']) || $data['Sdate'] == "" || !isset($data['Edate']) || $data['Edate'] == "" || !isset($data['title']) || $data['title'] == "" || !isset($data['price']) || $data['price'] == "" || !isset($data['location']) || $data['location'] == "" || !isset($data['bedrooms']) || $data['bedrooms'] == "" || !isset($data['bathrooms']) || $data['bathrooms'] == "" || !isset($data['parking']) || $data['parking'] == "" || !isset($data['amenities']) || $data['amenities'] == "" || !isset($data['description']) || $data['description'] == "" || !isset($data['url']) || $data['url'] == ""){
                return $this->response("error", "Missing fields", 400);
            }

            //Storing the data in variables
            $api_key = $data['api_key'];
            $auction_id = $data['auction_id'];
            $name = $data['name'];
            $title = $data['title'];
            $price = $data['price'];
            $location = $data['location'];
            $bedrooms = $data['bedrooms'];
            $bathrooms = $data['bathrooms'];
            $parking = $data['parking'];
            $amenities = $data['amenities'];
            $description = $data['description'];
            $state = "Waiting";

            // Get the date from the request data
            $Sdate = $data['Sdate'];
            $Edate = $data['Edate'];

            // Validate date formats
            $myStartDate = new DateTime($Sdate);
            $myEndDate = new DateTime($Edate);
            $Sdate = $myStartDate->format('Y-m-d');
            $Edate = $myEndDate->format('Y-m-d');

            if (!$Sdate || !$Edate){
                return $this->response("error", "Incorrect date format", 400);
            }

            $imageUrl = $data['url'];

            //Storing the values into the database
            $stmt = $this->dataBase->prepare("INSERT INTO auction (auction_id, auction_name, auction_start_date, auction_end_date, title, price, location, bedrooms, bathrooms, parking, amenities, description, image_url, highest_bid, state, API_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            if (!$stmt){
                return $this->response("error", "Failed to prepare SQL statement: " . $this->dataBase->error, 500);
            }

            $stmt->bind_param("sssssisiiisssiss", $auction_id, $name, $Sdate, $Edate, $title, $price, $location, $bedrooms, $bathrooms, $parking, $amenities, $description, $imageUrl, $price, $state, $api_key);

            if (!$stmt->execute()){
                return $this->response("error", "Failed to execute SQL statement: " . $stmt->error, 500);
            }

            return $this->response("success", "Auction created successfully", 200, array("apikey" => $api_key));
        }

        public function getAuction($data){

            if (isset($data['auction_id'])){
                $auction_id = $data['auction_id'];

                $stmt = $this->dataBase->prepare("SELECT * from auction WHERE auction_id = ?");
                $stmt->bind_param("i", $auction_id);
                $stmt->execute();
                $auctions = $stmt->get_result();
    
                if (!$auctions){
                    return $this->response("error", "Failed to fetch listings.", 500);
                }
    
                $auctionData = [];
    
                while ($row = $auctions->fetch_assoc()){
                    $auctionData[] = $row;
                }
    
                return $this->response("success", "Retrieved listing successfully", 200, $auctionData);
            }

            else{
                $stmt = $this->dataBase->prepare("SELECT * from auction");
                $stmt->execute();
                $auctions = $stmt->get_result();

                if (!$auctions){
                    return $this->response("error", "Failed to fetch listings.", 500);
                }

                $auctionData = [];

                while ($row = $auctions->fetch_assoc()){
                    $auctionData[] = $row;
                }

                return $this->response("success", "Retrieved listings successfully", 200, $auctionData);
            }
        }
        public function updateAuction($data){
            if (!isset($data['apikey']) || $data['apikey'] == ""){
                return $this->response("error", "Missing API", 400);
            }

            $api_key = $data['apikey'];

            $auctionAPI = $this->dataBase->prepare("SELECT * FROM auction WHERE API_key = ?");
            $auctionAPI->bind_param("s", $api_key);
            $auctionAPI->execute();
            $result = $auctionAPI->get_result();

            if ($result->num_rows == 0) {
                return $this->response("error", "Auction does not exist", 404);
            }

            if (!isset($data["auction_id"]) && $data["auction_id"] == "" && !isset($data["state"]) && $data["state"] == "" && !isset($data["buyer"]) && $data["buyer"] == ""){
                if (!isset($data["highest_bid"]) || $data["highest_bid"] == ""){
                    return $this->response("error", "Missing Highest Bid", 400);
                }

                $highest_bid = $data['highest_bid'];

                $stmt = $this->dataBase->prepare("UPDATE auction SET highest_bid=? WHERE API_key=?");

                if (!$stmt){
                    return $this->response("error", "Failed to prepare SQL statement: " . $this->dataBase->error, 500);
                }

                $stmt->bind_param("is", $highest_bid, $api_key);

                if (!$stmt->execute()){
                    return $this->response("error", "Failed to execute SQL statement: " . $stmt->error, 500);
                }

                return $this->response("success", "Highest Bid updated successfully", 200, array("apikey" => $api_key));
            }

            else if (!isset($data["auction_id"]) && $data["auction_id"] == "" && !isset($data["highest_bid"]) && $data["highest_bid"] == "" && !isset($data["buyer"]) && $data["buyer"] == ""){
                if (!isset($data["state"]) || $data["state"] == ""){
                    return $this->response("error", "Missing State", 400);
                }

                $state = $data['state'];

                $stmt = $this->dataBase->prepare("UPDATE auction SET state=? WHERE API_key=?");

                if (!$stmt){
                    return $this->response("error", "Failed to prepare SQL statement: " . $this->dataBase->error, 500);
                }

                $stmt->bind_param("ss", $state, $api_key);

                if (!$stmt->execute()){
                    return $this->response("error", "Failed to execute SQL statement: " . $stmt->error, 500);
                }

                return $this->response("success", "State updated successfully", 200, array("apikey" => $api_key));
            }

            else if (!isset($data["auction_id"]) && $data["auction_id"] == "" && !isset($data["highest_bid"]) && $data["highest_bid"] == "" && !isset($data["state"]) && $data["state"] == ""){
                if (!isset($data["buyer"]) || $data["buyer"] == ""){
                    return $this->response("error", "Missing buyer", 400);
                }

                $buyer = $data['buyer'];

                $stmt = $this->dataBase->prepare("UPDATE auction SET buyer=? WHERE API_key=?");

                if (!$stmt){
                    return $this->response("error", "Failed to prepare SQL statement: " . $this->dataBase->error, 500);
                }

                $stmt->bind_param("ss", $buyer, $api_key);

                if (!$stmt->execute()){
                    return $this->response("error", "Failed to execute SQL statement: " . $stmt->error, 500);
                }

                return $this->response("success", "Buyer updated successfully", 200, array("apikey" => $api_key));
            }

            else if (!isset($data["buyer"]) && $data["buyer"] == "" && !isset($data["highest_bid"]) && $data["highest_bid"] == "" && !isset($data["state"]) && $data["state"] == ""){
                if (!isset($data["auction_id"]) || $data["auction_id"] == ""){
                    return $this->response("error", "Missing Auction ID", 400);
                }

                $auction_id = $data['auction_id'];

                $stmt = $this->dataBase->prepare("UPDATE auction SET auction_id=? WHERE API_key=?");

                if (!$stmt){
                    return $this->response("error", "Failed to prepare SQL statement: " . $this->dataBase->error, 500);
                }

                $stmt->bind_param("ss", $auction_id, $api_key);

                if (!$stmt->execute()){
                    return $this->response("error", "Failed to execute SQL statement: " . $stmt->error, 500);
                }

                return $this->response("success", "Auction ID updated successfully", 200, array("apikey" => $api_key));
            }

            else {
                $buyer = $data['buyer'];
                $state = $data['state'];
                $highest_bid = $data['highest_bid'];

                $stmt = $this->dataBase->prepare("UPDATE auction SET highest_bid=?, state=?, buyer=? WHERE API_key=?");

                if (!$stmt){
                    return $this->response("error", "Failed to prepare SQL statement: " . $this->dataBase->error, 500);
                }

                $stmt->bind_param("isss", $highest_bid, $state, $buyer, $api_key);

                if (!$stmt->execute()){
                    return $this->response("error", "Failed to execute SQL statement: " . $stmt->error, 500);
                }

                return $this->response("success", "Auction updated successfully", 200, array("apikey" => $api_key));
            }
        }
    }

    $api = API::getInstance($conn);
    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $postData = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($postData['type'])){
            echo $api->response("error", "Post parameters are missing", 400);
        } 
        
        else{
            switch ($postData['type']){
                case 'Register':
                    echo $api->register($postData);
                    break;

                case 'Login':
                    echo $api->login($postData);
                    break;

                case 'GetAllMovies':
                    echo $api->getAllMovies($postData);
                    break;

                case 'Recommend':
                    echo $api->recommend($postData);
                    break;

                case 'getFavourites':
                    echo $api->getFavourites($postData);
                    break;

                case 'CreateAuction':
                    echo $api->createAuction($postData);
                    break;

                case 'UpdateAuction':
                    echo $api->updateAuction($postData);
                    break;

                case 'GetAuction':
                    echo $api->getAuction($postData);
                    break;

                default:
                    echo $api->response("error", "Invalid type parameter", 400);
            }
        }
    } 
    
    else{
        echo $api->response("error", "Invalid request method", 405);
    }