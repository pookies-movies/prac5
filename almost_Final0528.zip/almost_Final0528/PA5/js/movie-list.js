window.onload = function(){
    //loadingScreen();
    clearInnerHTML();
    getAllMovies();

    document.getElementById('filter-selector').addEventListener('change', function() {
        const type = this.value;
        clearInnerHTML();
        getAllFilterMovies(type);
    });
}

function clearInnerHTML(){
    let movieItems = document.querySelectorAll('.movie-container');
    movieItems.forEach(movieItem => {
        movieItem.innerHTML = '';
    });
}

function getAllMovies(){
    //loadingScreen();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListHTML(listingIndex);
                }
                //hideLoadingScreen();
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        fuzzy: true,
        return: ['Title', 'MovieID', 'Rating', 'Runtime', 'AgeRating', 'Genre', 'CrewID', 'ReleaseYear', 'Image']
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
}

function populateListHTML(listData){
    let listingsContainer = document.querySelector('.movie-container');
    let listElement = document.createElement('div');
    listElement.classList.add('movie-item-style-2');
    listElement.innerHTML = `
        <img src="${listData.Image}" alt="">
        <div class="mv-item-infor" id=${listData.MovieID}>
            <h6><a href="moviesingle.html?MovieId=${listData.MovieID}">${listData.Title} <span>(${listData.ReleaseYear})</span></a></h6>
            <p class="rate"><i class="ion-android-star"></i><span>${listData.Rating}</span> /10</p>
            <p class="describe">${listData.Description}</p>
            <p class="run-time"> Run Time: ${listData.Runtime}’    .     <span>MMPA: ${listData.AgeRating} </span>    .     <span>Release: ${listData.ReleaseYear}</span></p>
        </div>
    `;

    listingsContainer.appendChild(listElement);
}

/*-----------------------------------------------------------------------------------------------------------------------------------------*/

function getAllFilterMovies(type){
    //loadingScreen();
    clearInnerHTML();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListHTML(listingIndex);
                }
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        sort: type,
        order: "DESC",
        return: ['Title', 'MovieID', 'Rating', 'Runtime', 'AgeRating', 'Genre', 'CrewID', 'ReleaseYear', 'Image']
    };

    xmlObject.send(JSON.stringify(reqData));
}

function search(){
    //loadingScreen();
    let data = document.getElementById('search-input').value;
    clearInnerHTML();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListHTML(listingIndex);
                }
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        search: data,
        fuzzy: true
    };

    xmlObject.send(JSON.stringify(reqData));
}