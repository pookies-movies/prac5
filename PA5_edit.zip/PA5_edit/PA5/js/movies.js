window.onload = function(){
    //loadingScreen();
    let listingsContainer = document.querySelector('.slick-multiItemSlider');
    listingsContainer.innerHTML = '';
    getAllMovies();
    document.getElementById('search-select').addEventListener('change', function() {
        const sortBy = this.value;
        let listingsContainer = document.querySelector('.slick-multiItemSlider');
        listingsContainer.innerHTML = '';
        getAllSortMovies(sortBy);
    });
}

/*function loadingScreen(){
    document.getElementById('loading-screen').style.display = 'block';
}

function hideLoadingScreen(){
    setTimeout(function(){
        document.getElementById('loading-screen').style.display = 'none';
    }, 1000);
}*/

function getAllMovies(){
    //loadingScreen();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListHTML(listingIndex);
                }
                //hideLoadingScreen();
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        fuzzy: true,
        return: ['Title', 'MovieID', 'Rating', 'Runtime', 'AgeRating', 'Genre', 'CrewID', 'ReleaseYear', 'Image']
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
}

function populateListHTML(listData){
    let listingsContainer = document.querySelector('.slick-multiItemSlider');
    let listElement = document.createElement('div');
    listElement.classList.add('movie-item');
    listElement.innerHTML = `
        <div class="mv-img">
            <!--link to the movie-->
            <a href="moviesingle.html"><img src="${listData.Images}" alt="" width="285" height="437"></a>
        </div>
        <div class = "title-in" id = "${listData.MovieID}">
            <div class="cate">
                <span class="blue"><a href="#">${listData.Genre}</a></span>
            </div>
            <h6><a href="#">${listData.Title}</a></h6>
            <p><i class="ion-android-star"></i><span>7.4</span> /10</p>
        </div>
    `;

    listingsContainer.appendChild(listElement);
}

/*-----------------------------------------------------------------------------------------------------------------------------------------*/

function getAllSortListings(sortBy){
    //loadingScreen();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListHTML(listingIndex);
                }
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: 'GetAllMovies',
        apikey: api,
        order: 'ASC',
        sort: sortBy,
        return: ['Title', 'MovieID', 'Rating', 'Runtime', 'AgeRating', 'Genre', 'CrewID', 'ReleaseYear', 'Image']
    };

    xmlObject.send(JSON.stringify(reqData));
}