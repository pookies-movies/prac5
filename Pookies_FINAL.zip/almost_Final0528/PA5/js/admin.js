window.onload = function(){
    clearInnerHTML();
    getAllMovies();
}

const form = document.getElementById('movieForm');
const typeSelect = document.getElementById('type');
const seasonsInput = document.getElementById('seasons');
const updateButton = document.getElementById('updateButton');
const searchBar = document.getElementById('searchBar');
const moviesList = document.getElementById('moviesList');
let isEditing = false;
let currentMovieId = null;

function clearInnerHTML(){
    let movieItems = document.querySelectorAll('#moviesList');
    movieItems.forEach(movieItem => {
        movieItem.innerHTML = '';
    });
}

function getAllMovies(){
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListHTML(listingIndex);
                }
            }

            else{
                console.error(response.message);
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        fuzzy: true,
        return: ['Title', 'MovieID', 'Rating', 'Runtime', 'AgeRating', 'Genre', 'CrewID', 'ReleaseYear', 'Image']
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
}

function populateListHTML(listData){
    let listingsContainer = document.querySelector('#moviesList');
    let listElement = document.createElement('div');
    listElement.classList.add('movie-item');
    listElement.innerHTML = `
        <strong>${listData.Title}</strong> (${listData.ReleaseYear}) - ${listData.Genre}
        <button onclick="editMovie('${listData.MovieID}')">Edit</button>
        <button onclick="deleteMovie('${listData.MovieID}')">Delete</button>
        <img src="${listData.Image}" alt="${listData.Title}">
    `;

    listingsContainer.appendChild(listElement);
}

function search(){
    //loadingScreen();
    console.log('search');
    let data = document.getElementById('searchBar').value;
    clearInnerHTML();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                for (let i = 0; i < listData.length; i++){
                    let listingIndex = listData[i];
                    populateListHTML(listingIndex);
                }
            }

            else{
                console.error(response.message);
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        search: data,
        fuzzy: true
    };

    xmlObject.send(JSON.stringify(reqData));
}

function createMS(event){
    event.preventDefault();
    console.log("Adding Movie....");
    clearInnerHTML();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                console.log("Movie Added!");
                getAllMovies();
            }

            else{
                console.error(response.message);
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");
    let Type;
    if (typeSelect.value === 'movie'){
        Type = 'AddMovie';
    }

    else if (typeSelect.value === 'series'){
        Type = 'AddSeries';
    }

    let movieData = {
        type: Type,
        api_key: api,
        Title: form.title.value,
        Genre: form.genre.value,
        ReleaseYear: Number(form.year.value),
        AgeRating: form.pgRating.value,
        Description: form.description.value,
        Image: form.imageUrl.value,
        Runtime: form.runtime.value,
        Rating: 3,
        CrewID: form.crewID.value,
        Director: form.director.value,
        seasons: typeSelect.value === 'series' ? Number(form.seasons.value) : null,
    };

    xmlObject.send(JSON.stringify(movieData));
}

function deleteMovie(id){
    clearInnerHTML();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                console.log("Movie deleted successfully:(");
                getAllMovies();
                //hideLoadingScreen();
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "DeleteMovie",
        api_key: api,
        MovieID: id
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
}

window.editMovie = function(id){
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                let listIndex = listData[0];
                form.type.value = 'movie';
                form.title.value = listIndex.Title;
                form.genre.value = listIndex.Genre;
                form.year.value = listIndex.ReleaseYear;
                form.pgRating.value = listIndex.AgeRating;
                form.description.value = listIndex.Description;
                form.imageUrl.value = listIndex.Image;
                form.runtime.value = listIndex.Runtime;
                form.crewID.value = listIndex.CrewID;
                form.director.value = listIndex.Director;

                seasonsInput.value = '';
                seasonsInput.classList.add('hidden');

                isEditing = true;
                currentMovieId = id;
                updateButton.style.display = 'block';
                window.history.pushState({}, null, `admin.html?MovieID=${id}`);
            }

            else{
                console.error(response.message);
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        id: id,
        return: ['Title', 'MovieID', 'Rating', 'Runtime', 'AgeRating', 'Genre', 'CrewID', 'ReleaseYear', 'Image']
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
};

function updateMS(){
    const params = new URLSearchParams(window.location.search);
    const movieID = params.get('MovieID');

    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                console.log("Movie updated!");
                clearInnerHTML();
                getAllMovies();
            }

            else{
                console.error(response.message);
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: 'UpdateMovie',
        api_key: api,
        MovieID: movieID,
        Title: form.title.value,
        Genre: form.genre.value,
        ReleaseYear: Number(form.year.value),
        AgeRating: form.pgRating.value,
        Description: form.description.value,
        Image: form.imageUrl.value,
        Runtime: form.runtime.value,
        Rating: 3,
        CrewID: form.crewID.value,
        Director: form.director.value,
        seasons: typeSelect.value === 'series' ? Number(form.seasons.value) : null,
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
}