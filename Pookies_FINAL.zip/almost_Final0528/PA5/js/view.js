window.onload = function(){
    //loadingScreen();
    const params = new URLSearchParams(window.location.search);
    const movieID = params.get('MovieId');
    const SeriesID = params.get('SeriesId');
    //clearInnerHTML();
    if (movieID !== null){
        getAllMovies(movieID);
    } 
    
    else if (SeriesID !== null){
        getAllSeries(SeriesID);
    }
}

/*function clearInnerHTML(){
    let movieItems = document.querySelectorAll('.slick-multiItemSlider .movie-item');
    movieItems.forEach(movieItem => {
        console.log(movieItem.innerHTML);
    });
    movieItems.forEach(movieItem => {
        movieItem.innerHTML = '';
    });
}*/

function getAllMovies(movieID){
    //loadingScreen();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                populateListHTML(listData[0]);
                //hideLoadingScreen();
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllMovies",
        apikey: api,
        id: movieID,
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
}

function populateListHTML(listData){
    console.log(listData);
    var movieImage = document.getElementById('movie-image');
    movieImage.src = `${listData.Image}`;

    var movieTitle = document.querySelector('.bd-hd');
    movieTitle.innerHTML = `${listData.Title} <span>${listData.ReleaseYear}</span>`;

    var ratingSpan = document.querySelector('.rate p span');
    ratingSpan.textContent = `${listData.Rating}`;

    var descriptionParagraph = document.querySelector('#overview p');
    descriptionParagraph.textContent = `${listData.Description}`;

    let sbItems = document.querySelectorAll('.sb-it');
    if (sbItems.length > 0){
        // Update Genres
        if (sbItems[1]) {
            let genresP = sbItems[1].querySelector('p');
            if (genresP) {
                genresP.innerHTML = `<a href="#">${listData.Genre}</a>`; // Change genres as needed
            }
        }
    
        // Update Release Date
        if (sbItems[2]) {
            let releaseDateP = sbItems[2].querySelector('p');
            if (releaseDateP) {
                releaseDateP.textContent = `${listData.ReleaseYear}`;
            }
        }
    
        // Update Run Time
        if (sbItems[3]) {
            let runTimeP = sbItems[3].querySelector('p');
            if (runTimeP) {
                runTimeP.textContent = `${listData.Runtime}`;
            }
        }
    
        // Update MMPA Rating
        if (sbItems[4]) {
            let ratingP = sbItems[4].querySelector('p');
            if (ratingP) {
                ratingP.textContent = `${listData.AgeRating}`;
            }
        }
    }

    let rvHdDiv = document.querySelector('.rv-hd');

    // Check if the parent div exists
    if (rvHdDiv) {
        // Select the h2 element within the parent div
        let h2Element = rvHdDiv.querySelector('h2');
        h2Element.innerHTML = `${listData.Title}`;
    }

    let castDiv = document.querySelector('#cast');

    // Check if the parent div exists
    if (castDiv) {
        // Select the h2 element within the parent div
        let h2Elementcast = castDiv.querySelector('h2');
        h2Elementcast.innerHTML = `${listData.Title}`;
    }
}

function getAllSeries(SeriesID){
    //loadingScreen();
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let listData = response.data;
                populateListSeriesHTML(listData[0]);
                //hideLoadingScreen();
            }

            else{
                console.error(response.message);
                //hideLoadingScreen();
            }
        }
    }

    let api = sessionStorage.getItem("apiKey");

    let reqData = {
        type: "GetAllSeries",
        apikey: api,
        id: SeriesID,
    };

    console.log(reqData);

    xmlObject.send(JSON.stringify(reqData));
}

function populateListSeriesHTML(listData){
    console.log(listData);
    var movieImage = document.getElementById('movie-image');
    movieImage.src = `${listData.Image}`;

    var movieTitle = document.querySelector('.bd-hd');
    movieTitle.innerHTML = `${listData.Title} <span>${listData.ReleaseYear}</span>`;

    var ratingSpan = document.querySelector('.rate p span');
    ratingSpan.textContent = `${listData.Rating}`;

    var descriptionParagraph = document.querySelector('#overview p');
    descriptionParagraph.textContent = `${listData.Description}`;

    let sbItems = document.querySelectorAll('.sb-it');
    if (sbItems.length > 0){
        // Update Genres
        if (sbItems[1]) {
            let genresP = sbItems[1].querySelector('p');
            if (genresP) {
                genresP.innerHTML = `<a href="#">${listData.Genre}</a>`; // Change genres as needed
            }
        }
    
        // Update Release Date
        if (sbItems[2]) {
            let releaseDateP = sbItems[2].querySelector('p');
            if (releaseDateP) {
                releaseDateP.textContent = `${listData.ReleaseYear}`;
            }
        }
    
        let h6Elements = sbItems[3].querySelectorAll('h6'); // Select h6 elements within the fourth .sb-it element

        // Loop through all h6 elements to find the one containing "Run Time:"
        h6Elements.forEach(h6Element => {
            if (h6Element.textContent.trim() === 'Run Time:') {
                h6Element.textContent = 'Seasons:'; // Change the text content to 'Seasons:'
            }
        });

        if (sbItems[3]) {
            let season = sbItems[3].querySelector('p');
            if (season) {
                season.textContent = `${listData.Seasons}`;
            }
        }
    
        // Update MMPA Rating
        if (sbItems[4]) {
            let ratingP = sbItems[4].querySelector('p');
            if (ratingP) {
                ratingP.textContent = `${listData.AgeRating}`;
            }
        }
    }

    let rvHdDiv = document.querySelector('.rv-hd');

    // Check if the parent div exists
    if (rvHdDiv) {
        // Select the h2 element within the parent div
        let h2Element = rvHdDiv.querySelector('h2');
        h2Element.innerHTML = `${listData.Title}`;
    }

    let castDiv = document.querySelector('#cast');

    // Check if the parent div exists
    if (castDiv) {
        // Select the h2 element within the parent div
        let h2Elementcast = castDiv.querySelector('h2');
        h2Elementcast.innerHTML = `${listData.Title}`;
    }
}