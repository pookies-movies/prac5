function registerSubmit(event){
    event.preventDefault();
    console.log("Im here");
    let name = document.getElementById('username-2').value.toString();
    let surname = document.getElementById('surname-2').value.toString();
    let email = document.getElementById('email-2').value.toString();
    let password = document.getElementById('password-2').value.toString();
    let genre = document.getElementById('pref-genre-2').value.toString();
    console.log(name + " " + surname + " " + email + " " + password + " " + genre);
    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    //xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let api = response.data.apikey;
                sessionStorage.setItem("apiKey", api);
                window.location.href = 'login.html';
            }
        }

        else{
            let response = JSON.parse(xmlObject.responseText);
            /*let errorMessage = document.getElementById('error-message');
            errorMessage.textContent = response.message;
            errorMessage.style.display = 'block';*/
            console.error(response.message);
        }
    }

    let reqData = {
        type: "Register",
        name: name,
        surname: surname,
        email: email,
        password: password,
        genre: genre
    };

    reqData = JSON.stringify(reqData);
    console.log(reqData);

    xmlObject.send(reqData);
}

function loginSubmit(event){
    event.preventDefault();
    console.log("Im here too");
    let email = document.getElementById('email').value.toString();
    let password = document.getElementById('password').value.toString();

    let xmlObject = new XMLHttpRequest();
    let apiURL = 'https://wheatley.cs.up.ac.za/u23547627/221/pookies_api.php';
    var username = "u23547627";
    var apiPassword = "C1k2G3d4";
    xmlObject.open('POST', apiURL, true);
    xmlObject.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + apiPassword));
    //xmlObject.setRequestHeader("Content-Type", "application/json");
    xmlObject.onreadystatechange = function(){
        if (xmlObject.readyState === 4 && xmlObject.status === 200){
            let response = JSON.parse(xmlObject.responseText);
            
            if (response.status === "success"){
                let api = response.data.apikey;
                sessionStorage.setItem("apiKey", api);
                window.location.href = 'index.html';
            }
        }

        else{
            let response = JSON.parse(xmlObject.responseText);
            /*let errorMessage = document.getElementById('error-message');
            errorMessage.textContent = response.message;
            errorMessage.style.display = 'block';*/
            console.error(response.message);
        }
    }

    let reqData = {
        type: "Login",
        email: email,
        password: password
    };

    reqData = JSON.stringify(reqData);
    console.log(reqData);

    xmlObject.send(reqData);
}